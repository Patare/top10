import './App.css';
import Home  from './component/Home/home'
function App() {
  return (
    <div className="App">
    <Home/>
    </div>  
  );
}

export default App; 







// import React, { useState } from "react";
// import {
//   AppBar,
//   Toolbar,
//   Button,
//   Menu,
//   MenuItem,
//   Typography,
//   IconButton,
//   Drawer,
//   List,
//   ListItem,
//   ListItemText,
//   Box,
// } from "@mui/material";
// import MenuIcon from "@mui/icons-material/Menu";

// function App() {
//   const [anchorEl, setAnchorEl] = useState(null);
//   const [menuType, setMenuType] = useState(null);
//   const [mobileOpen, setMobileOpen] = useState(false);

//   const handleClick = (event, type) => {
//     setAnchorEl(event.currentTarget);
//     setMenuType(type);
//   };

//   const handleClose = () => {
//     setAnchorEl(null);
//     setMenuType(null);
//   };

//   const handleMenuItemClick = (value) => {
//     console.log("selected value is =>", value);
//     handleClose();
//   };

//   const handleDrawerToggle = () => {
//     setMobileOpen(!mobileOpen);
//   };

//   return (
//     <div>
//       <AppBar position="static" >
//         <Toolbar >
//           <IconButton
//             edge="start"
//             color="inherit"
//             aria-label="menu"
//             onClick={handleDrawerToggle}
//             sx={{ mr: 2,display: { xs: 'flex', md: 'none'} }}
//           >
//             <MenuIcon />
//           </IconButton>
//           <Box  sx={{display: { xs: 'none', md: 'flex'},justifyContent: "space-between"}}>
//           <Typography button variant="h6" component="div" sx={{ flexGrow: 1,cursor :"pointer",marginLeft:"2px" }} onClick={(e) => handleClick(e, "home")}>
//         Home
//           </Typography>
//           <Typography variant="h6" component="div" sx={{ flexGrow: 1,cursor :"pointer",marginLeft:"5px"  }} onClick={(e) => handleClick(e, "contact")}>
//           contact
//           </Typography>
//           <Typography variant="h6" component="div" sx={{ flexGrow: 1,cursor :"pointer",marginLeft:"10px"  }} onClick={(e) => handleClick(e, "products")}>
//           products
//           </Typography>
//           </Box>
//         </Toolbar>
//       </AppBar>

//       <Drawer
//         anchor="left"
//         open={mobileOpen}
//         onClose={handleDrawerToggle}
//         ModalProps={{
//           keepMounted: true,  
//         }}
//         sx={{display: { xs: 'flex', md: 'none' }}}
//       >
//         <List>
//           <ListItem button onClick={(e) => handleClick(e, "home")}>
//             <ListItemText primary="Home" />
//           </ListItem>
//           <ListItem button onClick={(e) => handleClick(e, "contact")}>
//             <ListItemText primary="Contact" />
//           </ListItem>
//           <ListItem button onClick={(e) => handleClick(e, "products")}>
//             <ListItemText primary="Products" />
//           </ListItem>
//         </List>
//       </Drawer>

//       <Toolbar /> {/* Ensure content below app bar */}

//       <Menu
//         id="menu"
//         anchorEl={anchorEl}
//         keepMounted
//         open={Boolean(anchorEl)}
//         onClose={handleClose}
//         sx={{  overflow: 'hidden'}}
//       >
//         {menuType === "home" && (
//           <>
//             <MenuItem onClick={() => handleMenuItemClick("Option 1")}>
//               Option 1
//             </MenuItem>
//             <MenuItem onClick={() => handleMenuItemClick("Option 2")}>
//               Option 2
//             </MenuItem>
//             <MenuItem onClick={() => handleMenuItemClick("Option 3")}>
//               Option 3
//             </MenuItem>
//           </>
//         )}
//         {menuType === "contact" && (
//           <>
//             <MenuItem onClick={() => handleMenuItemClick("Option 4")}>
//               Option 4
//             </MenuItem>
//             <MenuItem onClick={() => handleMenuItemClick("Option 5")}>
//               Option 5
//             </MenuItem>
//             <MenuItem onClick={() => handleMenuItemClick("Option 6")}>
//               Option 6
//             </MenuItem>
//           </>
//         )}
//         {menuType === "products" && (
//           <>
//             <MenuItem onClick={() => handleMenuItemClick("Option 7")}>
//               Option 7
//             </MenuItem>
//             <MenuItem onClick={() => handleMenuItemClick("Option 8")}>
//               Option 8
//             </MenuItem>
//             <MenuItem onClick={() => handleMenuItemClick("Option 9")}>
//               Option 9
//             </MenuItem>
//           </>
//         )}
//       </Menu>
//     </div>
//   );
// }

// export default App;
